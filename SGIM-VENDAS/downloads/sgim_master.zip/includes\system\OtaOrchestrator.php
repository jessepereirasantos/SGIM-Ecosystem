<?php
/**
 * SGIM CLIENT - OTA TRANSACTIONAL ORCHESTRATOR
 * Coordenador de estados dos motores industriais.
 * MODO: DRY_RUN (PROTEÇÃO MÁXIMA)
 */

namespace SGIM\OTA;

use Exception;

// Inclusões Manuais (Segurança Máxima)
require_once __DIR__ . '/OtaDownloadEngine.php';
require_once __DIR__ . '/OtaExtractionEngine.php';
require_once __DIR__ . '/OtaMigrationEngine.php';
require_once __DIR__ . '/OtaCapabilityManager.php';
require_once __DIR__ . '/OtaManifestValidator.php';
require_once __DIR__ . '/OtaBackupEngine.php';
require_once __DIR__ . '/ProtectedPathsPolicy.php';
require_once __DIR__ . '/drivers/SharedHostingDriver.php';

class OtaOrchestrator {
    private $basePath;
    private $masterUrl; // ✅ FIX: recebido via construtor, não hardcoded
    private $config = [
        "dry_run"                   => false,
        "activation_enabled"        => true,
        "manual_approval_required"  => false
    ];
    
    private $downloadEngine;
    private $extractionEngine;
    private $migrationEngine;
    private $activationDriver;
    private $capabilityManager;

    public function __construct($pdo, $basePath, $masterUrl = 'https://escolateologicaeloha.com.br') {
        $this->basePath  = rtrim($basePath, '/') . '/';
        $this->masterUrl = rtrim($masterUrl, '/');

        $this->downloadEngine   = new OtaDownloadEngine($this->basePath);
        $this->extractionEngine = new OtaExtractionEngine($this->basePath);
        $this->migrationEngine  = new OtaMigrationEngine($pdo, $this->basePath);
        
        // FORÇAR DRIVER (Segurança Máxima para HostGator)
        if (!$this->activationDriver) {
            $this->activationDriver = new \SGIM\OTA\Drivers\SharedHostingDriver($this->basePath, $pdo);
        }
    }

    /**
     * Fluxo Transacional Integrado
     */
    public function updateLifecycle() {
        try {
            $driverName = $this->activationDriver ? get_class($this->activationDriver) : 'NENHUM';
            $this->log("Iniciando Ciclo Integrado (Driver: " . $driverName . ")");
            
            // Garantir diretórios base (Self-Healing)
            foreach (['shared/system/logs', 'shared/system/state', 'shared/system/downloads', 'releases'] as $dir) {
                if (!file_exists($this->basePath . $dir)) @mkdir($this->basePath . $dir, 0755, true);
            }

            // 1. Discovery (Manifest)
            try {
                $manifest = $this->discovery();
                $this->updateState('discovery', ["last_manifest" => $manifest]);
            } catch (Exception $e) {
                throw new Exception("DISCOVERY STAGE FAIL: " . $e->getMessage());
            }
            
            // 2. Download & Verify SHA256
            $downloadOk = $this->downloadEngine->downloadPackage($manifest['url'], $manifest['sha256'], $manifest['version']);
            if ($downloadOk !== true) {
                // Lê o log para capturar o motivo exato da falha
                $logFile = $this->basePath . 'shared/system/logs/download.log';
                $lastLog = file_exists($logFile) ? implode('', array_slice(file($logFile), -5)) : 'Log indisponível';
                throw new Exception("DOWNLOAD FALHOU (hash mismatch ou erro de rede). Últimas entradas do log:\n" . $lastLog);
            }
            $this->updateState('download', ["version" => $manifest['version'], "status" => "SUCCESS"]);

            // 3. Extraction & Structural Validation
            try {
                $versionPath = $this->basePath . "releases/v" . $manifest['version'] . "/";
                $this->extractionEngine->extract($manifest['version'], $this->basePath . "shared/system/downloads/release_{$manifest['version']}.zip");
                
                // Persistir o manifesto na pasta recém-criada para que o commitUpdate possa ler depois!
                file_put_contents($versionPath . 'release_manifest.json', json_encode($manifest, JSON_PRETTY_PRINT));
                
                $this->updateState('extraction', ["version" => $manifest['version'], "status" => "SUCCESS"]);
            } catch (Exception $e) {
                throw new Exception("EXTRACTION STAGE FAIL: " . $e->getMessage());
            }

            // 4. Driver Staging (Backup + Impact Report)
            if ($this->activationDriver) {
                $this->activationDriver->prepareActivation($versionPath, $manifest);
            }

            // 5. Database Migrations (Auto-execution)
            $this->log("Iniciando Migrações Automáticas...");
            $this->migrationEngine->migrate();
            $this->updateState('migration', ["status" => "SUCCESS"]);

            // 6. WAIT STATE (Aprovação Manual Obrigatória)
            $this->log("[WAIT] Sistema pronto em STAGING. Aguardando comando manual para COMMIT.");
            return "READY_FOR_COMMIT";

        } catch (Exception $e) {
            $this->log("FALHA NO CICLO INTEGRADO: " . $e->getMessage());
            return "FAIL";
        }
    }

    /**
     * Execução Final (Ativação Real)
     */
    public function commitUpdate($version) {
        try {
            $this->log("COMANDO MANUAL: Ativando versão $version");
            $versionPath = $this->basePath . "releases/v" . $version . "/";
            $manifestPath = $versionPath . 'release_manifest.json';
            $manifest = file_exists($manifestPath) ? json_decode(file_get_contents($manifestPath), true) : [];
            
            if ($this->activationDriver->activate($versionPath, $manifest)) {
                // ✅ PERSISTÊNCIA DETERMINÍSTICA: Atualiza a versão no banco de dados local
                try {
                    $stmt = $this->migrationEngine->getPDO()->prepare("UPDATE configuracoes SET valor = ? WHERE chave = 'versao_sistema'");
                    $stmt->execute([$version]);
                    $this->log("Banco de dados atualizado para v$version.");
                } catch (Exception $dbEx) {
                    $this->log("AVISO: Falha ao atualizar versão no banco: " . $dbEx->getMessage());
                }

                $this->updateState('activation', ["version" => $version, "status" => "ACTIVE"]);
                return true;
            }
            return false;
        } catch (Exception $e) {
            $this->log("ERRO NO COMMIT: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Reversão Manual
     */
    public function rollbackUpdate($version) {
        try {
            $this->log("COMANDO MANUAL: Revertendo versão $version");
            return $this->activationDriver->rollback($version);
        } catch (Exception $e) {
            $this->log("ERRO NO ROLLBACK: " . $e->getMessage());
            return false;
        }
    }

    private function discovery() {
        $url = $this->masterUrl . '/api/update/latest.json';
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Compatibilidade com SSL legados
        $json = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new Exception("Falha ao consultar Master (HTTP $httpCode) em: $url. Erro: $error");
        }

        $manifest = json_decode($json, true);
        if (!$manifest || !isset($manifest['version'])) {
            throw new Exception("Manifesto JSON inválido recebido de: $url. Resposta: " . substr($json, 0, 100));
        }
        return $manifest;
    }

    private function updateState($key, $data) {
        $stateFile = $this->basePath . 'shared/system/state/current_state.json';
        $state = file_exists($stateFile) ? json_decode(file_get_contents($stateFile), true) : [];
        $state[$key] = array_merge($data, ["updated_at" => date('c')]);
        file_put_contents($stateFile, json_encode($state, JSON_PRETTY_PRINT));
    }

    private function rollback() {
        $this->log("ROLLBACK TRANSACIONAL EXECUTADO: Mantendo sistema em base estável.");
    }

    private function log($message) {
        $logFile = $this->basePath . 'shared/system/logs/orchestrator.log';
        $entry = "[" . date('Y-m-d H:i:s') . "] " . $message . "\n";
        file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    }
}
