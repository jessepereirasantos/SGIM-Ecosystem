<?php
// ARQUIVO DE CONFIGURAÇÃO DE BANCO LOCAL PARA DESENVOLVIMENTO
$is_configured = true;
$is_installed_local = true;
$host = 'localhost';
$dbname = 'sgim_local';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    $is_configured = false;
    $pdo = null;
}
?>
