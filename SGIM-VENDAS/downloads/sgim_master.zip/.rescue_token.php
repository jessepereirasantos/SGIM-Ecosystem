<?php
return 'SGIM-RESCUE-2026';
